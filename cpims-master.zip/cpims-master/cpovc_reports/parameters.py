# Report names
RPTS = {}
RPTS[1] = 'DATIM'
RPTS[2] = 'PEPFAR'
RPTS[3] = 'KPI'
RPTS[4] = 'DATIM'
RPTS[5] = 'DATIM'
RPTS[6] = 'OTHER'
#
ORPTS = {}
ORPTS[1] = 'Registration list'
ORPTS[2] = 'Registration by HH'
ORPTS[3] = 'CSI'
ORPTS[4] = 'CHV monthly RR'
ORPTS[5] = 'List of OVC not served'
ORPTS[6] = 'PEPFAR detailed summary'
ORPTS[7] = 'Registration by CHV'
ORPTS[8] = 'Beneficiary list'
ORPTS[9] = 'Form1a summary'
ORPTS[10] = 'Needs vs Served by domain'
