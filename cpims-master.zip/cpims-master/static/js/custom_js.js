//custom_js.js

function jsCreateUser(person_id,person_name)
{
  	 localStorage.setItem("person_id",person_id);
	 //return location.href='{% url 'new_user' %}';
     //console.log()
}

function jsViewDetails(person_name)
{
    //alert("person_id "+person_id);
}
function jsFunction()
{
}