"""This is for versioning and identifaction."""

default_app_config = 'cpovc_ovc.apps.OVCAppConfig'
