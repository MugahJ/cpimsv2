default_app_config = 'cpims.apps.AuthAppConfig'
